is.superthin <- function(x){
	inherits(x, "superthin")	
}