is.devresid <- function(x){
	inherits(x, "devresid")	
}