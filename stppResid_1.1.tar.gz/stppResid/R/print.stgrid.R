print.stgrid <- function(x, ...)
{
	cat("Spatial grid\n")
	print(x$grid.full)
}