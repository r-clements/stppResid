is.gridresid <- function(x){
	inherits(x, "gridresid")	
}