is.tessresid <- function(x){
	inherits(x, "tessresid")	
}