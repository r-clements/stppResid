is.thinresid <- function(x){
	inherits(x, "thinresid")	
}