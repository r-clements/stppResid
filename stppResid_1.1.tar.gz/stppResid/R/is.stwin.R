is.stwin <- function(x){
	inherits(x, "stwin")	
}