is.tessdev <- function(x){
	inherits(x, "tessresid")	
}