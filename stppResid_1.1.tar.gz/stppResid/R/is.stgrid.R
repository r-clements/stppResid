is.stgrid <- function(x){
	inherits(x, "stgrid")	
}