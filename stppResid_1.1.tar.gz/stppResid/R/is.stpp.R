is.stpp <- function(x){
	inherits(x, "stpp")	
}