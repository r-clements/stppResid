is.supresid <- function(x){
	inherits(x, "supresid")	
}